# -*- coding: utf-8 -*-


"""molbery.__main__: executed when molbery directory is called as script."""


from .molbery import main
main()
